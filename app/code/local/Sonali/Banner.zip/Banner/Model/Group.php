<?php
class Sonali_Banner_Model_Group extends Mage_Core_Model_Abstract
{
	function __construct()
	{
		$this->_init('banner/group');
	}
}